// This script runs when the extension's popup is opened.

document.addEventListener("DOMContentLoaded", () => {
    console.log("Popup DOM loaded. Checking for analysis result...");

    // Get references to the different views and the result elements in the popup
    const defaultView = document.getElementById("default-view");
    const resultView = document.getElementById("result-view");
    const verdictEl = document.getElementById("result-verdict");
    const confidenceLevelEl = document.getElementById("confidence-level");
    const explanationEl = document.getElementById("result-explanation");
    const referenceUrlsList = document.querySelector("#reference-urls ul");
    const referenceContainer = document.getElementById('reference-urls');

    // Try to get the analysis result that the background script saved
    chrome.storage.local.get("analysisResult", (data) => {
        console.log("Popup received data from storage:", data);

        if (chrome.runtime.lastError) {
            console.error("Error getting data from storage:", chrome.runtime.lastError);
            return;
        }

        const result = data.analysisResult;

        // If a result exists in storage, display it
        if (result) {
            console.log("Result found, displaying result view.");
            if (defaultView) defaultView.classList.add("hidden");
            if (resultView) resultView.classList.remove("hidden");

            // --- Populate the result elements ---
            if (verdictEl) {
                const verdict = result.verdict || 'N/A';
                verdictEl.textContent = `Verdict: ${verdict}`;
                verdictEl.className = 'verdict'; // Reset class
                verdictEl.classList.add(verdict.toLowerCase());
            }
            
            if (confidenceLevelEl) {
                const confidence = result.confidence_score || 'unknown';
                confidenceLevelEl.textContent = `Confidence: ${confidence}`;
                confidenceLevelEl.className = 'confidence-level'; // Reset class
                confidenceLevelEl.classList.add(confidence.toLowerCase());
            }

            if (explanationEl) {
                explanationEl.textContent = result.explanation || "No explanation provided.";
            }

            if (referenceUrlsList && referenceContainer) {
                referenceUrlsList.innerHTML = ''; // Clear previous URLs
                if (result.reference_urls && result.reference_urls.length > 0) {
                    referenceContainer.style.display = 'block';
                    result.reference_urls.forEach(url => {
                        const listItem = document.createElement('li');
                        const link = document.createElement('a');
                        link.href = url;
                        link.textContent = url;
                        link.target = '_blank';
                        link.rel = "noopener noreferrer"; 
                        listItem.appendChild(link);
                        referenceUrlsList.appendChild(listItem);
                    });
                } else {
                     referenceContainer.style.display = 'none';
                }
            }

            // IMPORTANT: Clear the result from storage
            chrome.storage.local.remove("analysisResult", () => {
                console.log("Result displayed and cleared from storage.");
            });
            
        } else {
            // If no result is found, make sure the default view is shown
            console.log("No result found in storage. Showing default view.");
            if (defaultView) defaultView.classList.remove("hidden");
            if (resultView) resultView.classList.add("hidden");
        }
    });
});

