const API_URL = "https://your-backend.com/api/check/";

let currentType = "text";
let currentData = "";

// Load stored data if coming from context menu
document.addEventListener("DOMContentLoaded", async () => {
  const stored = await chrome.storage.local.get(["inputType", "data"]);
  if (stored.inputType) {
    currentType = stored.inputType;
    currentData = stored.data;

    if (currentType === "text") {
      document.getElementById("textInput").value = currentData;
    }
    if (currentType === "image" && currentData) {
      const preview = document.getElementById("imagePreview");
      preview.src = currentData;
      preview.style.display = "block";
      document.getElementById("textInput").hidden = true;
    }

    chrome.storage.local.remove(["inputType", "data"]);
  }
});

// Button listeners
document.getElementById("btnText").addEventListener("click", () => {
  currentType = "text";
  document.getElementById("fileInput").hidden = true;
  document.getElementById("textInput").hidden = false;
  document.getElementById("imagePreview").style.display = "none";
});

document.getElementById("btnImage").addEventListener("click", () => {
  currentType = "image";
  document.getElementById("fileInput").hidden = false;
  document.getElementById("fileInput").accept = "image/*";
  document.getElementById("textInput").hidden = true;
});

document.getElementById("btnVideo").addEventListener("click", () => {
  currentType = "video";
  document.getElementById("fileInput").hidden = false;
  document.getElementById("fileInput").accept = "video/*";
  document.getElementById("textInput").hidden = true;
});

document.getElementById("fileInput").addEventListener("change", (e) => {
  currentData = e.target.files[0];
  if (currentType === "image" && currentData instanceof File) {
    const preview = document.getElementById("imagePreview");
    preview.src = URL.createObjectURL(currentData);
    preview.style.display = "block";
  }
});

document.getElementById("btnCheck").addEventListener("click", async () => {
  const loading = document.getElementById("loading");
  const result = document.getElementById("result");
  loading.classList.remove("hidden");
  result.textContent = "";

  let formData = new FormData();

  if (currentType === "text") {
    currentData = document.getElementById("textInput").value.trim();
    if (!currentData) {
      loading.classList.add("hidden");
      result.textContent = "Please enter some text.";
      return;
    }
    formData.append("text", currentData);
  } else if (currentType === "image" && typeof currentData === "string") {
    const blob = await (await fetch(currentData)).blob();
    formData.append("image", blob, "capture.png");
  } else if (currentType === "image" && currentData instanceof File) {
    formData.append("image", currentData);
  } else if (currentType === "video" && currentData instanceof File) {
    formData.append("video", currentData);
  } else {
    loading.classList.add("hidden");
    result.textContent = "Please provide a valid file.";
    return;
  }

  try {
    const res = await fetch(API_URL, { method: "POST", body: formData });
    const json = await res.json();
    loading.classList.add("hidden");
    result.textContent = JSON.stringify(json, null, 2);
  } catch (err) {
    loading.classList.add("hidden");
    result.textContent = "Error: " + err.message;
  }
});
