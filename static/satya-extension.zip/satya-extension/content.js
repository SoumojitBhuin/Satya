chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "showOverlay") {
    createOverlay(message.inputType, message.data);
  }
});

function createOverlay(type, data) {
  // Remove old overlay if exists
  let oldOverlay = document.getElementById("satya-extension-overlay");
  if (oldOverlay) oldOverlay.remove();

  // Overlay container
  let overlay = document.createElement("div");
  overlay.id = "satya-extension-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "20px";
  overlay.style.right = "20px";
  overlay.style.zIndex = "999999";
  overlay.style.background = "#fff";
  overlay.style.border = "2px solid #5148ff";
  overlay.style.borderRadius = "8px";
  overlay.style.boxShadow = "0 4px 12px rgba(0,0,0,0.2)";
  overlay.style.padding = "10px";
  overlay.style.maxWidth = "300px";
  overlay.style.maxHeight = "400px";
  overlay.style.overflow = "auto";

  // Close button
  let closeBtn = document.createElement("button");
  closeBtn.innerText = "×";
  closeBtn.style.float = "right";
  closeBtn.style.border = "none";
  closeBtn.style.background = "transparent";
  closeBtn.style.fontSize = "20px";
  closeBtn.style.cursor = "pointer";
  closeBtn.onclick = () => overlay.remove();
  overlay.appendChild(closeBtn);

  // Content
  if (type === "image") {
    let img = document.createElement("img");
    img.src = data;
    img.style.maxWidth = "100%";
    overlay.appendChild(img);
  } else if (type === "text") {
    let p = document.createElement("p");
    p.innerText = data;
    p.style.whiteSpace = "pre-wrap";
    overlay.appendChild(p);
  }

  document.body.appendChild(overlay);
}
