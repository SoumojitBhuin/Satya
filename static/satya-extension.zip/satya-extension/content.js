// This script is not strictly necessary for the context menu functionality
// but is included for completeness and future features.
// For example, you could use this script to highlight scanned text on the page.

console.log("Satya content script loaded.");
