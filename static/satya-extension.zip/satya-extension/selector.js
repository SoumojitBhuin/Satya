let overlay, selectionBox;
let startX, startY, endX, endY;

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "startRegionSelect") {
    createOverlay();
  }
});

function createOverlay() {
  overlay = document.createElement("div");
  overlay.id = "satya-overlay";
  document.body.appendChild(overlay);

  selectionBox = document.createElement("div");
  selectionBox.id = "satya-selection";
  overlay.appendChild(selectionBox);

  overlay.addEventListener("mousedown", startSelection);
}

function startSelection(e) {
  startX = e.clientX;
  startY = e.clientY;

  selectionBox.style.left = `${startX}px`;
  selectionBox.style.top = `${startY}px`;
  selectionBox.style.width = "0px";
  selectionBox.style.height = "0px";

  overlay.addEventListener("mousemove", resizeSelection);
  overlay.addEventListener("mouseup", finishSelection);
}

function resizeSelection(e) {
  endX = e.clientX;
  endY = e.clientY;

  selectionBox.style.left = `${Math.min(startX, endX)}px`;
  selectionBox.style.top = `${Math.min(startY, endY)}px`;
  selectionBox.style.width = `${Math.abs(endX - startX)}px`;
  selectionBox.style.height = `${Math.abs(endY - startY)}px`;
}

function finishSelection() {
  overlay.removeEventListener("mousemove", resizeSelection);
  overlay.removeEventListener("mouseup", finishSelection);

  let coords = {
    x: Math.min(startX, endX),
    y: Math.min(startY, endY),
    width: Math.abs(endX - startX),
    height: Math.abs(endY - startY)
  };

  overlay.remove();
  chrome.runtime.sendMessage({ type: "regionSelected", coords });
}
