Open Your Browser and go to: Extensions -> Manage Extensions

Enable Developer mode (toggle in the top-right corner)

Click “Load unpacked” button

Select the folder where you unzipped the .zip file (make sure it contains the manifest.json file)

The SatyaAI will load and appear in the list of installed extensions

You can now use the Satya from the toolbar