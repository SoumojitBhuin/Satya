// API URL for your backend - REMEMBER TO REPLACE THIS WITH YOUR DEPLOYED URL
// For local testing, ensure your Flask app is running.
const API_URL = "https://satya-one.vercel.app/verify";

// --- Context Menu Setup ---
chrome.runtime.onInstalled.addListener(() => {
  // Create a context menu item for selected text
  chrome.contextMenus.create({
    id: "verify-text",
    title: "Verify selected text with Satya",
    contexts: ["selection"],
  });

  // Create a context menu item for images
  chrome.contextMenus.create({
    id: "verify-image",
    title: "Verify image with Satya",
    contexts: ["image"],
  });
});

// --- Listener for Context Menu Clicks ---
chrome.contextMenus.onClicked.addListener((info, tab) => {
  let requestData;

  if (info.menuItemId === "verify-text" && info.selectionText) {
    requestData = {
      type: "text",
      data: info.selectionText,
    };
  } else if (info.menuItemId === "verify-image" && info.srcUrl) {
    // For images, we send the URL. The backend will handle fetching it.
    // Note: For local files or complex scenarios, a different approach might be needed.
    // This implementation assumes the backend can handle a base64 data URL.
    requestData = {
      type: "image",
      data: info.srcUrl,
    };
  }

  if (requestData) {
    // Call the function to send data to the backend
    verifyWithBackend(requestData);
  }
});


async function verifyWithBackend(data) {
    console.log("Background: Sending data to backend:", data);

    try {
        // If the data is an image URL, we need to convert it to base64 first
        if (data.type === 'image') {
            const response = await fetch(data.data);
            const blob = await response.blob();
            data.data = await blobToBase64(blob);
        }

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        console.log("Background: Received result from backend:", result);

        // --- THIS IS THE FIX ---
        // Save the result to storage, and only open the popup in the callback
        // This prevents the race condition.
        chrome.storage.local.set({ analysisResult: result }, () => {
            console.log("Background: Result saved to storage.");

            // Now that the data is saved, open the popup
            chrome.action.openPopup();
        });

    } catch (error) {
        console.error("Background: Error during verification:", error);
        // Even if there's an error, save an error object so the popup can display it
        const errorResult = {
            verdict: 'Error',
            explanation: 'Failed to connect to the verification service. Please ensure the local server is running and accessible.'
        };
        chrome.storage.local.set({ analysisResult: errorResult }, () => {
             console.log("Background: Error result saved to storage.");
             chrome.action.openPopup();
        });
    }
}

function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

