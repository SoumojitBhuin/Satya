chrome.runtime.onInstalled.addListener(() => {
  // Context menu for text selection
  chrome.contextMenus.create({
    id: "checkText",
    title: "Check authenticity of selected text",
    contexts: ["selection"]
  });

  // Context menu for screenshot
  chrome.contextMenus.create({
    id: "checkScreenshot",
    title: "Check authenticity of screenshot",
    contexts: ["page"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "checkText") {
    chrome.storage.local.set({ inputType: "text", data: info.selectionText }, () => {
      openExtensionPopup(tab);
    });
  }

  if (info.menuItemId === "checkScreenshot") {
    chrome.tabs.sendMessage(tab.id, { type: "startRegionSelect" });
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === "regionSelected") {
    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (image) => {
      cropImage(image, msg.coords).then(croppedImage => {
        chrome.storage.local.set({ inputType: "image", data: croppedImage }, () => {
          openExtensionPopup(sender.tab);
        });
      });
    });
  }
});

async function cropImage(base64, coords) {
  const img = await createImageBitmap(await (await fetch(base64)).blob());
  const canvas = new OffscreenCanvas(coords.width, coords.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, coords.x, coords.y, coords.width, coords.height, 0, 0, coords.width, coords.height);
  const blob = await canvas.convertToBlob();
  return await blobToBase64(blob);
}

function blobToBase64(blob) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.readAsDataURL(blob);
  });
}

function openExtensionPopup(tab) {
  //open the popup in a small window
  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 400,
    height: 600
  });
}
